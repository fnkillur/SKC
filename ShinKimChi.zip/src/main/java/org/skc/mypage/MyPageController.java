package org.skc.mypage;

public class MyPageController {

}
