package org.skc.reviewpage;

public class ReviewPageController {

}
