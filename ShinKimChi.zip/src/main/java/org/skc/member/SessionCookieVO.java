package org.skc.member;

public class SessionCookieVO {

	public String session;
	public String cookie;
	public String rememberDate;
	public String cookieDate;
	
	public String getSession() {
		return session;
	}
	public void setSession(String session) {
		this.session = session;
	}
	public String getCookie() {
		return cookie;
	}
	public void setCookie(String cookie) {
		this.cookie = cookie;
	}
	public String getRememberDate() {
		return rememberDate;
	}
	public void setRememberDate(String rememberDate) {
		this.rememberDate = rememberDate;
	}
	public String getCookieDate() {
		return cookieDate;
	}
	public void setCookieDate(String cookieDate) {
		this.cookieDate = cookieDate;
	}
	
}
