package org.skc.storepage;

public class StorePageController {

}
